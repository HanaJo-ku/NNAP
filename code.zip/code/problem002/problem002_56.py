a=[]
for i in range(10):a.append(int(input()))
a.sort()
print(a[9],a[8],a[7],sep='\n');