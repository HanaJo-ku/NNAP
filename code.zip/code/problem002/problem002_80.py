s = list()

for i in range(10):
    s.append(input())

s.sort(reverse = True)

for i in range(3):
    print s[i]