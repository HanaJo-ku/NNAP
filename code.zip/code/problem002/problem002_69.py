array = [int(input()) for i in range(10)]
array.sort()
for i in range(9,6,-1):
    print(array[i])