a = list(reversed(sorted([int(raw_input()) for _ in range(10)])))
print a[0]
print a[1]
print a[2]