for i in range(9):
    i=i+1
    for j in range(9):
        j=j+1
        print(str(i)+'x'+str(j)+'='+str(i*j))