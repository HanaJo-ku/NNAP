for a in range(1,10):
	for b in range(1,10):
		i = a * b
		print(a,"x",b,"=",i,sep="")
	
