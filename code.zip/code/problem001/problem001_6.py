for a in range(1,10):
    for b in range(1,10):
        ans = a*b
        print("%dx%d=%d" % (a, b, ans))