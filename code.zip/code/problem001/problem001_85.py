def __main():
    x = 1;
    while x <= 9 :
        y = 1;
        while y <= 9 :
             z = x * y;
             print(str(x) + "x" + str(y)  + "=" + str(z) )
             y = y + 1
        x = x + 1
        
        
__main()

