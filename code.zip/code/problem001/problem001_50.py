for i in range(1,10):
    for j in range(1,10):
        a=i*j
        print(f'{i}x{j}={a}')
