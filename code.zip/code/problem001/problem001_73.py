for a in range(1,10):
 for b in range(1,10): print "%dx%d=%d" %(a,b,a*b)