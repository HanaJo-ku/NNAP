x = range(1,10)
for i in x:
  for j in x:
    print u"%dx%d=%d"%(i, j, i*j)