for i in range(1, 10):
    a=i
    b=1
    while  True:
        print(a,"x",b,"=",a*b,sep="")
        if b==9:
            break
        b+=1
