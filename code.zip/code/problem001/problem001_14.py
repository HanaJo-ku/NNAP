a = range(1, 10)
[print('{}x{}={}'.format(i, j, i * j)) for i in a for j in a]