for num1 in range(1,10):
    for num2 in range(1,10):
        i = num1 * num2
        print(str(num1) + "x" + str(num2) + "=" + str(i))

