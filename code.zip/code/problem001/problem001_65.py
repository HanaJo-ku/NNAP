#coding: utf-8

for i in range(9):
    for k in range(9):
        print str(i+1) + 'x' + str(k+1) + '=' + str((i+1) * (k+1))