i = 0
while i < 9:
    i = i + 1
    
    j = 0
    while j < 9:
        j = j + 1
        
        print (str(i) + 'x' + str(j) + '=' + str(i*j))
