for i in range(9):
  i+=1
  for n in range(9):
    n+=1
    print str(i)+"x"+str(n)+"="+str(i*n)