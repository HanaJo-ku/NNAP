a = [1, 2, 3, 4, 5, 6, 7, 8, 9]
b = [1, 2, 3, 4, 5, 6, 7, 8, 9]

for x in a:
    for y in a:
        ans = x * y
        print(str(x)+'x'+str(y)+'='+str(ans))

