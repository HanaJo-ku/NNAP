for i in xrange(1,10):
    for j in xrange(1,10):
        print str(i)+ "x" + str(j) +  "="  + str(i*j)