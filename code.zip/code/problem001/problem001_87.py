y = 1
while y<10:
    x = 1
    while x<10:
        print str(y)+'x'+str(x)+'='+str(y*x)
        x += 1
    y += 1