a=0
i=0
for a in range(1,10):
    for i in range(1,10):
        num1=a
        num2=i
        num3=a*i
     
        print(str(num1)+'x'+str(num2)+'='+str(num3))
