for i in range(1,10):
    for j in range(1,10):
        print("{0}{1}{2}{3}{4}".format(i,"x",j,"=",i*j))