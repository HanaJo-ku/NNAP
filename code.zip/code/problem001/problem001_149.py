# coding: utf-8
# Here your code !
for i in range(9):
    for j in range(9):
        print('%sx%s=%s' % ((i+1), (j+1), (i+1)*(j+1)))