for number1 in range(1, 10) :
    for number2 in range(1, 10) :
        print(str(number1) + 'x' +  str(number2) + '=' + str(number1 * number2))