a = 1
while a<10:
    b=1
    while b<10:
        print(str(a)+'x'+str(b)+'='+str(a*b))
        b=b+1
    a=a+1