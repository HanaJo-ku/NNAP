#!/usr/bin/env python3
# -*- coding: utf-8 -*-

if __name__ == '__main__':
	for i in range(1,10):
		for j in range(1,10):
			print('{}x{}={}'.format( i, j, i*j ))