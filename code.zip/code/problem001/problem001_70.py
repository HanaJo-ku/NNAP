for j in range(1,10,1):
    for k in range(1,10,1):
        print("{}x{}={}".format(j,k,j*k))
