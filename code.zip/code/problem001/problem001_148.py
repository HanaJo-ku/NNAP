i = 1

while i < 10 :
    j = 1
    while j < 10 :
        print(str(i) + "x" + str(j) + "=" + str(i*j))
        j += 1
    i += 1
