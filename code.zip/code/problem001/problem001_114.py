for i in range(1,10):
    for z in range(1,10):
        a = i * z
        print(str(i) + "x" + str(z) + "=" + str(a))

