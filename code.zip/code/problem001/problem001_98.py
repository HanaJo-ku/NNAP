for x in range(1,10):
    for i in range(1,10):
        print(f"{x}x{i}={x*i}")
