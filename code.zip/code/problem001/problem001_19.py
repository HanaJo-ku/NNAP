for i in xrange(1, 10):
    for j in xrange(1, 10):
        print "%dx%d=%d" % (i, j, i * j)