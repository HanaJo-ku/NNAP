for i in range(1,10):
    for s in range(1,10):
        result = str(i) + "x" + str(s) + "=" + str(int(i)*int(s))
        print(result)