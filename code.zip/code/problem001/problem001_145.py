r=range
s=str
for i in r(1,10):
    for u in r(1,10):
        print(s(i)+'x'+s(u)+'='+s(i*u))