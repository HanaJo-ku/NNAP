max = 10
for x in xrange(1, max):
	for y in xrange(1, max):
		print "%dx%d=%d" % (x, y, x * y)